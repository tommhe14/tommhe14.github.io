# -*- coding: utf-8 -*-
import sys
import os
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import requests, re, json, time
from urllib.parse import quote_plus, unquote

CACHE_TIME = 1800  

class Stalker:
    def __init__(self, portal=None, mac=None):
        self.addon = xbmcaddon.Addon()
        self.profile_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(self.profile_dir):
            xbmcvfs.mkdirs(self.profile_dir)

        self.session = requests.Session()
        self.session.verify = False
        self.token = None

        cached = self.load_cache('portal_info')
        if cached:
            self.portal = cached.get('portal', portal)
            self.mac = cached.get('mac', mac)
        else:
            self.portal = portal
            self.mac = mac

        if not self.portal or not self.mac:
            self.ask_for_portal()

        self.get_token()
    
    def get_cache_path(self, cache_name):
        return os.path.join(self.profile_dir, f"{cache_name}.json")
    
    def load_cache(self, cache_name):
        cache_file = self.get_cache_path(cache_name)
        if not xbmcvfs.exists(cache_file):
            return None
        try:
            with xbmcvfs.File(cache_file, 'r') as f:
                data = f.read()
                if not data:
                    return None
                cache_data = json.loads(data)
                return cache_data.get('data')
        except:
            return None

    def save_cache(self, cache_name, data):
        cache_file = self.get_cache_path(cache_name)
        cache_data = {'timestamp': time.time(), 'data': data}
        try:
            with xbmcvfs.File(cache_file, 'w') as f:
                f.write(json.dumps(cache_data))
            return True
        except:
            return False

    def ask_for_portal(self):
        dialog = xbmcgui.Dialog()
        kb = xbmc.Keyboard(self.portal or "", "Enter Stalker Portal URL (http://...)")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            self.portal = kb.getText().strip()

        kb = xbmc.Keyboard(self.mac or "", "Enter MAC Address")
        kb.doModal()
        if kb.isConfirmed() and kb.getText().strip():
            self.mac = kb.getText().strip()

        if not self.get_token():
            dialog.notification("Stalker", "Failed to connect. Please re-enter.", xbmcgui.NOTIFICATION_ERROR, 3000)
            self.ask_for_portal()
        else:
            self.save_cache('portal_info', {'portal': self.portal, 'mac': self.mac})

    def get_token(self):
        if not self.portal or not self.mac:
            return None
        self.session.cookies.clear()
        self.session.cookies.set('mac', self.mac)
        url = f"{self.portal}/portal.php?type=stb&action=handshake&JsHttpRequest=1-xml"
        try:
            r = self.session.get(url, timeout=10)
            match = re.search(r'"token"\s*:\s*"([^"]+)"', r.text)
            if match:
                self.token = match.group(1)
                return self.token
        except:
            pass
        return None

    def get_json(self, params):
        url = f"{self.portal}/portal.php?{params}&JsHttpRequest=1-xml"
        try:
            r = self.session.get(url, timeout=15)
            r.raise_for_status()
            try:
                data = r.json()
                if isinstance(data, dict) and 'js' in data:
                    js = data['js']
                    if isinstance(js, list):
                        return js
                    if isinstance(js, dict) and 'data' in js:
                        return js['data']
                    return js
                if isinstance(data, list):
                    return data
                return [data]
            except:
                return []
        except:
            return []

    def get_genres(self):
        cached = self.load_cache('genres')
        if cached is not None:
            return cached
        
        genres = self.get_json("type=itv&action=get_genres")
        if not isinstance(genres, list):
            genres = [genres]
        
        cleaned = []
        for genre in genres:
            if isinstance(genre, dict):
                gid = genre.get("id", "")
                title = genre.get("title", "Unknown")
                if gid or title != "Unknown":
                    cleaned.append({"id": str(gid), "title": title, "name": title})
        
        if cleaned:
            self.save_cache('genres', cleaned)
        return cleaned

    def get_all_channels(self):
        cached = self.load_cache('all_channels')
        if cached is not None:
            return cached
        
        channels = self.get_json("type=itv&action=get_all_channels")
        if not isinstance(channels, list):
            channels = [channels]

        cleaned = []
        for ch in channels:
            if isinstance(ch, dict):
                cmd = ch.get("cmd", "")
                if cmd.startswith("ffmpeg "):
                    cmd = cmd[7:].strip()
                cleaned.append({
                    "id": str(ch.get("id", "")),
                    "name": ch.get("name", ""),
                    "cmd": cmd,
                    "logo": ch.get("logo", ""),
                    "tv_genre_id": str(ch.get("tv_genre_id", ""))
                })
        
        if cleaned:
            self.save_cache('all_channels', cleaned)
        
        return cleaned

    def get_channels_by_genre(self, genre_id):
        if not genre_id:
            return self.get_all_channels()
        return [ch for ch in self.get_all_channels() if ch.get("tv_genre_id") == str(genre_id)]

    def search_channels(self, search_query):
        if not search_query:
            return []
        search_query = search_query.lower().strip()
        return [ch for ch in self.get_all_channels() if search_query in ch.get("name", "").lower()]

def router(paramstring):
    params = {}
    if paramstring:
        for p in paramstring.split("&"):
            if "=" in p:
                key, val = p.split("=", 1)
                params[key] = unquote(val)
    
    action = params.get("action", "")
    if action == "reenter":
        client = Stalker()
        client.ask_for_portal()
        xbmc.executebuiltin("Container.Refresh")
    elif action == "genre":
        show_genre(params.get("genre_id", ""), params.get("title", "Unknown"))
    elif action == "all":
        show_all()
    elif action == "play":
        play_channel(params.get("cmd", ""))
    elif action == "refresh":
        refresh_data()
    elif action == "search":
        show_search()
    elif action == "search_results":
        show_search_results(params.get("query", ""))
    else:
        show_genres()

def show_genres():
    client = Stalker()
    genres = client.get_genres()
    handle = int(sys.argv[1])
    xbmcplugin.setPluginCategory(handle, "Live TV")
    xbmcplugin.setContent(handle, "files")
    
    li = xbmcgui.ListItem(label="[COLOR yellow]⚙ Set Portal / MAC[/COLOR]")
    url = f"{sys.argv[0]}?action=reenter"
    xbmcplugin.addDirectoryItem(handle, url, li, True)
    
    li = xbmcgui.ListItem(label="[COLOR yellow]🔍 Search Channels[/COLOR]")
    url = f"{sys.argv[0]}?action=search"
    xbmcplugin.addDirectoryItem(handle, url, li, True)
    
    li = xbmcgui.ListItem(label="[COLOR yellow]📺 All Channels[/COLOR]")
    url = f"{sys.argv[0]}?action=all"
    xbmcplugin.addDirectoryItem(handle, url, li, True)

    for genre in genres:
        li = xbmcgui.ListItem(label=genre["title"])
        url = f"{sys.argv[0]}?action=genre&genre_id={quote_plus(genre['id'])}&title={quote_plus(genre['title'])}"
        xbmcplugin.addDirectoryItem(handle, url, li, True)
    
    xbmcplugin.endOfDirectory(handle)

def show_search():
    kb = xbmc.Keyboard("", "Search Channels")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        query = kb.getText().strip()
        show_search_results(query)
    else:
        xbmc.executebuiltin("Container.Refresh")

def show_search_results(query):
    client = Stalker()
    results = client.search_channels(query)
    handle = int(sys.argv[1])
    xbmcplugin.setPluginCategory(handle, f"Search: {query}")
    xbmcplugin.setContent(handle, "videos")
    
    if not results:
        li = xbmcgui.ListItem(label="[COLOR yellow]No channels found[/COLOR]")
        xbmcplugin.addDirectoryItem(handle, "", li, False)
    else:
        results.sort(key=lambda x: x["name"].lower())
        for ch in results:
            li = xbmcgui.ListItem(label=ch["name"])
            li.setInfo("video", {"title": ch["name"]})
            li.setProperty("IsPlayable", "true")
            if ch["logo"]:
                li.setArt({"thumb": ch["logo"], "icon": ch["logo"]})
            url = f"{sys.argv[0]}?action=play&cmd={quote_plus(ch['cmd'])}"
            xbmcplugin.addDirectoryItem(handle, url, li, False)
    
    li = xbmcgui.ListItem(label="[COLOR yellow]← New Search[/COLOR]")
    url = f"{sys.argv[0]}?action=search"
    xbmcplugin.addDirectoryItem(handle, url, li, False)
    
    xbmcplugin.endOfDirectory(handle)

def show_genre(genre_id, genre_title):
    client = Stalker()
    channels = client.get_channels_by_genre(genre_id)
    handle = int(sys.argv[1])
    xbmcplugin.setPluginCategory(handle, f"{genre_title} Channels")
    xbmcplugin.setContent(handle, "videos")
    
    if not channels:
        li = xbmcgui.ListItem(label="[COLOR yellow]No channels in this category[/COLOR]")
        xbmcplugin.addDirectoryItem(handle, "", li, False)
    else:
        channels.sort(key=lambda x: x["name"].lower())
        for ch in channels:
            li = xbmcgui.ListItem(label=ch["name"])
            li.setInfo("video", {"title": ch["name"]})
            li.setProperty("IsPlayable", "true")
            if ch["logo"]:
                li.setArt({"thumb": ch["logo"], "icon": ch["logo"]})
            url = f"{sys.argv[0]}?action=play&cmd={quote_plus(ch['cmd'])}"
            xbmcplugin.addDirectoryItem(handle, url, li, False)
    
    xbmcplugin.endOfDirectory(handle)

def show_all():
    client = Stalker()
    channels = client.get_all_channels()
    handle = int(sys.argv[1])
    xbmcplugin.setPluginCategory(handle, "All Channels")
    xbmcplugin.setContent(handle, "videos")
    
    channels.sort(key=lambda x: x["name"].lower())
    for ch in channels:
        li = xbmcgui.ListItem(label=ch["name"])
        li.setInfo("video", {"title": ch["name"]})
        li.setProperty("IsPlayable", "true")
        if ch["logo"]:
            li.setArt({"thumb": ch["logo"], "icon": ch["logo"]})
        url = f"{sys.argv[0]}?action=play&cmd={quote_plus(ch['cmd'])}"
        xbmcplugin.addDirectoryItem(handle, url, li, False)
    
    xbmcplugin.endOfDirectory(handle)

def refresh_data():
    client = Stalker()
    for cache_name in ['genres', 'all_channels']:
        cache_file = client.get_cache_path(cache_name)
        if xbmcvfs.exists(cache_file):
            xbmcvfs.delete(cache_file)
    client.get_token()
    xbmcgui.Dialog().notification("Stalker", "Data refreshed", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Refresh")

def play_channel(cmd):
    client = Stalker()
    stream_url = unquote(cmd).strip()
    
    if client.token and "token=" not in stream_url:
        stream_url = f"{stream_url}?token={client.token}" if "?" not in stream_url else f"{stream_url}&token={client.token}"
    
    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    li.setProperty("network.caching", "3000")
    
    if ".m3u8" in stream_url.lower():
        li.setMimeType("application/vnd.apple.mpegurl")
        if xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
    elif ".ts" in stream_url.lower():
        li.setMimeType("video/mp2t")
    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

if __name__ == "__main__":
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(paramstring)
