# -*- coding: utf-8 -*-
'''
***********************************************************
*
* @file addon.py
* @package script.module.thecrew
*
* Created on 2024-03-08.
* Copyright 2024 by The Crew. All rights reserved.
*
* @license GNU General Public License, version 3 (GPL-3.0)
*
********************************************************cm*
'''

# All credit goes to DrewLive for the fix, I am simply tailoring for an existing structure on KODI previously curated by TEAM CREW
# Check out DrewLives discord: https://discord.gg/5W3AXKCsrJ

import re
import os
import sys
import json
import html
import base64

from urllib.parse import urlencode, unquote, parse_qsl, quote_plus, urlparse, urljoin
from datetime import datetime, timezone

import requests
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import xbmcaddon


addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.daddylive')
mode = addon.getSetting('mode')

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
FANART = addon.getAddonInfo('fanart')
ICON = addon.getAddonInfo('icon')

SEED_BASEURL = 'https://daddylives.top/'

def get_headers(referer=None):
    """Get proper headers to bypass Cloudflare"""
    if referer is None:
        referer = get_active_base()
    
    return {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0',
        'Referer': referer,
    }

def log(msg):
    logpath = xbmcvfs.translatePath('special://logpath/')
    filename = 'daddylive.log'
    log_file = os.path.join(logpath, filename)
    try:
        if isinstance(msg, str):
            _msg = f'\n    {msg}'
        else:
            _msg = f'\n    {repr(msg)}'
        if not os.path.exists(log_file):
            with open(log_file, 'w', encoding='utf-8'):
                pass
        with open(log_file, 'a', encoding='utf-8') as f:
            line = ('[{} {}]: {}').format(datetime.now().date(), str(datetime.now().time())[:8], _msg)
            f.write(line.rstrip('\r\n') + '\n')
    except (TypeError, Exception) as e:
        try:
            xbmc.log(f'[ Daddylive ] Logging Failure: {e}', 2)
        except:
            pass

def load_m3u8_playlist():
    """Load channels from m3u8 playlist file - FILTERED for DaddyLive country categories only"""
    try:
        addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        playlist_file = os.path.join(addon_path, 'resources', 'playlist.m3u8')
        
        if not os.path.exists(playlist_file):
            xbmcgui.Dialog().notification("Daddylive", "Playlist file not found", ICON, 3000)
            log(f"Playlist file not found at: {playlist_file}")
            return []
        
        channels = []
        current_channel = {}
        skip_this_channel = False  
        
        with open(playlist_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        for line in lines:
            line = line.strip()
            
            if not line or line == '#EXTM3U':
                continue
            
            if line.startswith('#EXTINF:'):
                skip_this_channel = False
            
            if line.startswith('#EXTINF:'):
                if ',' in line:
                    extinf_parts = line.split(',', 1)
                    attributes_part = extinf_parts[0]
                    channel_name = extinf_parts[1]
                else:
                    attributes_part = line
                    channel_name = "Unknown Channel"
                
                group_match = re.search(r'group-title="([^"]+)"', attributes_part)
                
                if group_match:
                    group_title = group_match.group(1)
                    group_lower = group_title.lower()
                    
                    if not group_title.startswith('DaddyLive'):
                        skip_this_channel = True
                        continue
                    
                    adult_indicators = ['xxx', '18+', 'adult', 'porn', 'nsfw', 'explicit']
                    if any(indicator in group_lower for indicator in adult_indicators):
                        skip_this_channel = True
                        continue
                    
                    without_prefix = group_title.replace('DaddyLive', '').strip()
                    
                    if without_prefix.startswith('-'):
                        skip_this_channel = True
                        continue
                    
                    country_pattern = r'^\s*[A-Z]{2,3}(?:\s+[A-Z]{2,3})?\s*$'
                    if not re.match(country_pattern, without_prefix):
                        skip_this_channel = True
                        continue
                
                channel_lower = channel_name.lower()
                adult_name_indicators = ['xxx', '18+', 'adult', 'porn', 'nsfw', 'sex', 'explicit']
                if any(indicator in channel_lower for indicator in adult_name_indicators):
                    skip_this_channel = True
                    continue
                
                tvg_id_match = re.search(r'tvg-id="([^"]+)"', attributes_part)
                tvg_logo_match = re.search(r'tvg-logo="([^"]+)"', attributes_part)
                
                current_channel = {
                    'name': channel_name.strip(),
                    'tvg-id': tvg_id_match.group(1) if tvg_id_match else "",
                    'tvg-logo': tvg_logo_match.group(1) if tvg_logo_match else ICON,
                    'group-title': group_match.group(1) if group_match else ""
                }
            
            elif line.startswith('#EXTGRP:'):
                group = line.replace('#EXTGRP:', '').strip()
                group_lower = group.lower()
                
                if not group.startswith('DaddyLive'):
                    skip_this_channel = True
                    continue
                
                adult_indicators = ['xxx', '18+', 'adult', 'porn', 'nsfw', 'explicit']
                if any(indicator in group_lower for indicator in adult_indicators):
                    skip_this_channel = True
                    continue
                
                without_prefix = group.replace('DaddyLive', '').strip()
                
                if without_prefix.startswith('-'):
                    skip_this_channel = True
                    continue
                
                country_pattern = r'^\s*[A-Z]{2,3}(?:\s+[A-Z]{2,3})?\s*$'
                if not re.match(country_pattern, without_prefix):
                    skip_this_channel = True
                    continue
                
                if current_channel and not skip_this_channel:
                    current_channel['group-title'] = group
            
            elif line.startswith('http://') or line.startswith('https://'):
                if current_channel and not skip_this_channel:
                    # Final safety check
                    group_title = current_channel.get('group-title', '').lower()
                    channel_name = current_channel.get('name', '').lower()
                    
                    adult_indicators = ['xxx', '18+', 'adult', 'porn', 'nsfw', 'sex', 'explicit']
                    is_adult = (
                        any(indicator in group_title for indicator in adult_indicators) or
                        any(indicator in channel_name for indicator in adult_indicators)
                    )
                    
                    if not is_adult:
                        current_channel['url'] = line
                        channels.append(current_channel.copy())
                
                current_channel = {}
                skip_this_channel = False
        
        log(f"Loaded {len(channels)} DaddyLive country channels from m3u8 playlist")
        
        categories = {}
        for channel in channels:
            group = channel.get('group-title', 'Uncategorized')
            categories[group] = categories.get(group, 0) + 1
        
        if categories:
            log("Loaded country categories:")
            for category, count in sorted(categories.items()):
                log(f"  - {category}: {count} channels")
        
        return channels
        
    except Exception as e:
        log(f"Error loading m3u8 playlist: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Error loading playlist", ICON, 3000)
        return []

def load_extra_channels_json():
    """Load extra channels from the JSON file"""
    try:
        addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        json_file = os.path.join(addon_path, 'resources', 'extra_channels.json')
        
        if not os.path.exists(json_file):
            xbmcgui.Dialog().notification("Daddylive", "Extra channels file not found", ICON, 3000)
            log(f"Extra channels JSON file not found at: {json_file}")
            return []
        
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        channels = data.get('channels', [])
        log(f"Loaded {len(channels)} extra channels from JSON file")
        return channels
        
    except Exception as e:
        log(f"Error loading extra channels JSON: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Error loading extra channels", ICON, 3000)
        return []
    
def show_daddylive_categories():
    """Show DaddyLive categories from m3u8 playlist"""
    try:
        channels = load_m3u8_playlist()
        if not channels:
            addDir("[COLOR red]No channels found in playlist[/COLOR]", build_url({'mode': 'menu', 'serv_type': 'main'}), True)
            closeDir()
            return
        
        categories = {}
        for channel in channels:
            group = channel.get('group-title', 'Uncategorized')
            if group:
                if group not in categories:
                    categories[group] = []
                categories[group].append(channel)
        
        for category_name, category_channels in sorted(categories.items()):
            if not category_name or category_name == 'Uncategorized':
                continue
                
            if category_name.startswith('DaddyLive'):
                display_name = category_name.replace('DaddyLive', '').strip()
                if not display_name:
                    display_name = category_name
            else:
                display_name = category_name
            
            if not display_name:
                display_name = "Unknown Category"
            
            addDir(f"[B][COLOR gold]{display_name}[/COLOR][/B] ({len(category_channels)} channels)", 
                   build_url({'mode': 'show_daddylive_channel_group', 'category': category_name}), 
                   True)
        
        closeDir()
        
    except Exception as e:
        log(f"Error showing DaddyLive categories: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Error loading categories", ICON, 3000)
        closeDir()

def show_daddylive_channel_group(category):
    """Show channels for a specific DaddyLive category"""
    try:
        channels = load_m3u8_playlist()
        if not channels:
            addDir("[COLOR red]No channels found[/COLOR]", build_url({'mode': 'show_daddylive_categories'}), True)
            closeDir()
            return
        
        filtered_channels = [ch for ch in channels if ch.get('group-title', '') == category]
        
        if not filtered_channels:
            addDir(f"[COLOR red]No channels found in {category}[/COLOR]", 
                   build_url({'mode': 'show_daddylive_categories'}), 
                   True)
            closeDir()
            return
        
        filtered_channels.sort(key=lambda x: x.get('name', '').lower())
        
        for channel in filtered_channels:
            name = channel.get('name', 'Unknown Channel')
            logo = channel.get('tvg-logo', ICON)
            tvg_id = channel.get('tvg-id', '')
            channel_url = channel.get('url', '')
            
            clean_name = name
            if '(' in name and ')' in name:
                clean_name = name.split('(')[0].strip()
            
            li = xbmcgui.ListItem(clean_name)
            li.setArt({'thumb': logo, 'icon': logo, 'fanart': FANART})
            li.setInfo('video', {'title': clean_name, 'plot': name})  # Use full name as plot
            li.setProperty("IsPlayable", "true")
            
            channel_data = json.dumps({
                'name': clean_name,
                'url': channel_url,
                'logo': logo,
                'tvg-id': tvg_id
            })
            
            url = build_url({'mode': 'play_daddylive_channel', 'channel_data': channel_data})
            xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=False)
        
        closeDir()
        
    except Exception as e:
        log(f"Error showing DaddyLive channel group {category}: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Error loading channels", ICON, 3000)
        closeDir()

def play_daddylive_channel(channel_data):
    """Play a DaddyLive channel from m3u8 playlist"""
    try:
        data = json.loads(channel_data)
        name = data.get('name', 'Unknown Channel')
        url = data.get('url', '')
        logo = data.get('logo', ICON)
        
        if not url:
            xbmcgui.Dialog().notification("Daddylive", "No stream URL found", ICON, 3000)
            return
        
        log(f"Playing DaddyLive channel: {name}")
        log(f"Stream URL: {url}")
        
        play_url = url
        
        liz = xbmcgui.ListItem(name, path=play_url)
        liz.setArt({'thumb': logo, 'icon': logo, 'fanart': FANART})
        liz.setInfo('video', {'title': name, 'plot': f'DaddyLive: {name}'})
        
        liz.setProperty('inputstream', 'inputstream.adaptive')
        liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        liz.setMimeType('application/vnd.apple.mpegurl')
        log("Setting up HLS stream")
        
        liz.setProperty('IsPlayable', 'true')
        
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        log(f"Stream started for: {name}")
        
    except Exception as e:
        log(f"Error playing DaddyLive channel: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        xbmcgui.Dialog().notification("Daddylive", "Error playing channel", ICON, 3000)

def search_daddylive_channels():
    """Search for channels in the DaddyLive playlist"""
    keyboard = xbmcgui.Dialog().input("Search channels", type=xbmcgui.INPUT_ALPHANUM)
    if not keyboard or keyboard.strip() == '':
        return
    search_term = keyboard.lower().strip()
    
    try:
        channels = load_m3u8_playlist()
        if not channels:
            xbmcgui.Dialog().notification("Daddylive", "No channels loaded", ICON, 3000)
            return
        
        results = []
        for channel in channels:
            channel_name = channel.get('name', '').lower()
            group_name = channel.get('group-title', '').lower()
            
            if search_term in channel_name or search_term in group_name:
                results.append(channel)
        
        if not results:
            xbmcgui.Dialog().ok("Search", "No matching channels found.")
            return
        
        for channel in results:
            name = channel.get('name', 'Unknown Channel')
            logo = channel.get('tvg-logo', ICON)
            channel_url = channel.get('url', '')
            
            clean_name = name
            if '(' in name and ')' in name:
                clean_name = name.split('(')[0].strip()
            
            li = xbmcgui.ListItem(clean_name)
            li.setArt({'thumb': logo, 'icon': logo, 'fanart': FANART})
            li.setInfo('video', {'title': clean_name, 'plot': name})
            li.setProperty("IsPlayable", "true")
            
            channel_data = json.dumps({
                'name': clean_name,
                'url': channel_url,
                'logo': logo,
                'tvg-id': channel.get('tvg-id', '')
            })
            
            url = build_url({'mode': 'play_daddylive_channel', 'channel_data': channel_data})
            xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=False)
        
        closeDir()
        
    except Exception as e:
        log(f"Error searching DaddyLive channels: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Search error", ICON, 3000)

def show_a1xs_categories():
    """Show A1xmedia categories from the JSON file"""
    try:
        channels = load_extra_channels_json()
        if not channels:
            addDir("[COLOR red]No extra channels found[/COLOR]", build_url({'mode': 'menu', 'serv_type': 'main'}), True)
            closeDir()
            return
        
        categories = {}
        for channel in channels:
            group = channel.get('group-title', 'Uncategorized')
            if group not in categories:
                categories[group] = []
            categories[group].append(channel)
        
        for category_name, category_channels in sorted(categories.items()):
            display_name = category_name.replace('A1xmedia ', '') if category_name.startswith('A1xmedia ') else category_name
            addDir(f"[B][COLOR gold]{display_name}[/COLOR][/B] ({len(category_channels)} channels)", 
                   build_url({'mode': 'show_a1xs_channel_group', 'category': category_name}), 
                   True)
        
        closeDir()
        
    except Exception as e:
        log(f"Error showing A1xmedia categories: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Error loading categories", ICON, 3000)
        closeDir()

def show_a1xs_channel_group(category):
    """Show channels for a specific A1xmedia category"""
    try:
        channels = load_extra_channels_json()
        if not channels:
            addDir("[COLOR red]No channels found[/COLOR]", build_url({'mode': 'show_a1xs_categories'}), True)
            closeDir()
            return
        
        filtered_channels = [ch for ch in channels if ch.get('group-title', '') == category]
        
        if not filtered_channels:
            addDir(f"[COLOR red]No channels found in {category}[/COLOR]", 
                   build_url({'mode': 'show_a1xs_categories'}), 
                   True)
            closeDir()
            return
        
        for channel in filtered_channels:
            name = channel.get('name', 'Unknown Channel')
            logo = channel.get('tvg-logo', ICON)
            channel_id = channel.get('tvg-id', '')
            
            li = xbmcgui.ListItem(name)
            li.setArt({'thumb': logo, 'icon': logo, 'fanart': FANART})
            li.setInfo('video', {'title': name, 'plot': f'A1xmedia Channel: {name}'})
            li.setProperty("IsPlayable", "true")
            
            channel_data = json.dumps({
                'name': name,
                'url': channel.get('url', ''),
                'logo': logo,
                'tvg-id': channel_id
            })
            
            url = build_url({'mode': 'play_a1xs_channel', 'channel_data': channel_data})
            xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=False)
        
        closeDir()
        
    except Exception as e:
        log(f"Error showing A1xmedia channel group {category}: {e}")
        xbmcgui.Dialog().notification("Daddylive", "Error loading channels", ICON, 3000)
        closeDir()

def play_a1xs_channel(channel_data):
    """Play an A1xmedia channel from the JSON file"""
    try:
        data = json.loads(channel_data)
        name = data.get('name', 'Unknown Channel')
        url = data.get('url', '')
        logo = data.get('logo', ICON)
        
        if not url:
            xbmcgui.Dialog().notification("Daddylive", "No stream URL found", ICON, 3000)
            return
        
        log(f"Playing A1xmedia channel: {name}")
        log(f"Original URL: {url}")
        
        headers = {
            'User-Agent': UA,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Referer': 'https://a1xs.vip/'
        }
        
        try:
            response = requests.head(url, headers=headers, allow_redirects=True, timeout=10)
            final_url = response.url
            log(f"Final URL after redirects: {final_url}")
            
            play_url = final_url
            
        except Exception as e:
            log(f"Error following redirects: {e}")
            play_url = url  
        
        log(f"Using play URL: {play_url}")
        
        liz = xbmcgui.ListItem(name, path=play_url)
        liz.setArt({'thumb': logo, 'icon': logo, 'fanart': FANART})
        liz.setInfo('video', {'title': name, 'plot': f'A1xmedia: {name}'})
        
        if 'm3u8' in play_url.lower() or '.m3u8' in play_url.lower():
            liz.setProperty('inputstream', 'inputstream.adaptive')
            liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
            liz.setMimeType('application/vnd.apple.mpegurl')
            log("Setting up HLS stream")
        else:
            liz.setMimeType('video/mp4')
            log("Setting up direct stream")
        
        liz.setProperty('IsPlayable', 'true')
        
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        log(f"Stream started for: {name}")
        
    except Exception as e:
        log(f"Error playing A1xmedia channel: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        xbmcgui.Dialog().notification("Daddylive", "Error playing channel", ICON, 3000)

def normalize_origin(url):
    try:
        u = urlparse(url)
        return f'{u.scheme}://{u.netloc}/'
    except:
        return SEED_BASEURL

def resolve_active_baseurl(seed):
    try:
        s = requests.Session()
        headers = {'User-Agent': UA}
        resp = s.get(seed, headers=headers, timeout=10, allow_redirects=True)
        final = normalize_origin(resp.url if resp.url else seed)
        return final
    except Exception as e:
        log(f'Active base resolve failed, using seed. Error: {e}')
        return normalize_origin(seed)

def get_active_base():
    base = addon.getSetting('active_baseurl')
    if not base:
        base = resolve_active_baseurl(SEED_BASEURL)
        addon.setSetting('active_baseurl', base)
    if not base.endswith('/'):
        base += '/'
    return base

def set_active_base(new_base: str):
    if not new_base.endswith('/'):
        new_base += '/'
    addon.setSetting('active_baseurl', new_base)

def abs_url(path: str) -> str:
    """Convert old paths to new site structure"""
    base = get_active_base()
    
    if path == 'index.php' or 'index.php' in path:
        return urljoin(base, 'match-schedule/')
    elif path == '24-7-channels.php':
        return urljoin(base, '24-7-channels/')
    elif path.startswith('watch.php'):
        return urljoin(base, path)
    else:
        return urljoin(base, path.lstrip('/'))

def _sched_headers():
    base = get_active_base()
    return {'User-Agent': UA, 'Referer': base, 'Origin': base}

def get_local_time(utc_time_str):
    try:
        utc_now = datetime.utcnow()
        event_time_utc = datetime.strptime(utc_time_str, '%H:%M')
        event_time_utc = event_time_utc.replace(year=utc_now.year, month=utc_now.month, day=utc_now.day)
        event_time_utc = event_time_utc.replace(tzinfo=timezone.utc)
        local_time = event_time_utc.astimezone()
        time_format_pref = addon.getSetting('time_format')
        if time_format_pref == '1':
            local_time_str = local_time.strftime('%H:%M')
        else:
            local_time_str = local_time.strftime('%I:%M %p').lstrip('0')
        return local_time_str
    except Exception as e:
        log(f"Failed to convert time: {e}")
        return utc_time_str

def build_url(query):
    return addon_url + '?' + urlencode(query)

def addDir(title, dir_url, is_folder=True):
    li = xbmcgui.ListItem(title)
    clean_plot = re.sub(r'<[^>]+>', '', title)
    labels = {'title': title, 'plot': clean_plot, 'mediatype': 'video'}
    kodiversion = getKodiversion()
    if kodiversion < 20:
        li.setInfo("video", labels)
    else:
        infotag = li.getVideoInfoTag()
        infotag.setMediaType(labels.get("mediatype", "video"))
        infotag.setTitle(labels.get("title", "Daddylive"))
        infotag.setPlot(labels.get("plot", labels.get("title", "Daddylive")))
    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': ICON, 'fanart': FANART})
    li.setProperty("IsPlayable", 'false' if is_folder else 'true')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=dir_url, listitem=li, isFolder=is_folder)

def closeDir():
    xbmcplugin.endOfDirectory(addon_handle)

def getKodiversion():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion")[:2])
    except:
        return 18

def Main_Menu():
    menu = [
        ['[B][COLOR gold]DADDYLIVE CHANNELS[/COLOR][/B]', 'daddylive_channels'],
        ['[B][COLOR gold]EXTRA CHANNELS[/COLOR][/B]', 'a1xs'],
        ['[B][COLOR gold]SEARCH DADDYLIVE CHANNELS[/COLOR][/B]', 'search_daddylive'],
        ['[B][COLOR gold]REFRESH CATEGORIES[/COLOR][/B]', 'refresh'],
        ['[B][COLOR gold]SET ACTIVE DOMAIN (AUTO)[/COLOR][/B]', 'resolve_base_now'],
    ]
    for m in menu:
        addDir(m[0], build_url({'mode': 'menu', 'serv_type': m[1]}))
    closeDir()

def PlayStream(link):
    try:
        log(f'[PlayStream] Starting: {link}')
        
        channel_match = re.search(r'(\d{3})', link)
        if not channel_match:
            resp = requests.get(link, headers={'User-Agent': UA}, timeout=10)
            channel_match = re.search(r'(\d{3})', resp.text)
        
        if not channel_match:
            log('[PlayStream] No channel number found')
            return
        
        channel_id = channel_match.group(1)
        log(f'[PlayStream] Using channel: {channel_id}')
        
        target_m3u8 = f'https://chevy.giokko.ru/tv/premium{channel_id}/5893{channel_id}.m3u8'
        encoded_target = quote_plus(target_m3u8)
        proxy_url = f'http://drewlive2423.duckdns.org:4123?url={encoded_target}&channel={channel_id}'
        
        log(f'[PlayStream] Proxy URL: {proxy_url}')
        
        liz = xbmcgui.ListItem(f'Channel {channel_id}', path=proxy_url)
        
        liz.setProperty('inputstream', 'inputstream.adaptive')
        liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        liz.setMimeType('application/x-mpegURL')
        liz.setProperty('IsPlayable', 'true')
        
        xbmcplugin.setResolvedUrl(addon_handle, True, liz)
        log('[PlayStream] Stream started')
        
    except Exception as e:
        log(f'[PlayStream] Error: {e}')

def refresh_active_base():
    new_base = resolve_active_baseurl(SEED_BASEURL)
    set_active_base(new_base)
    xbmcgui.Dialog().ok("Daddylive", f"Active domain set to:\n{new_base}")
    xbmc.executebuiltin('Container.Refresh')

kodiversion = getKodiversion()
mode = params.get('mode', None)

if not mode:
    Main_Menu()
else:
    if mode == 'menu':
        servType = params.get('serv_type')
        if servType == 'daddylive_channels':
            show_daddylive_categories()
        elif servType == 'search_daddylive':
            search_daddylive_channels()
        elif servType == 'refresh':
            xbmc.executebuiltin('Container.Refresh')
        elif servType == 'a1xs':  
            show_a1xs_categories()
        elif servType == 'resolve_base_now':
            refresh_active_base()

    elif mode == 'play':
        link = params.get('url')
        PlayStream(link)

    elif mode == 'resolve_base_now':
        refresh_active_base()

    elif mode == 'show_daddylive_categories':
        show_daddylive_categories()
    
    elif mode == 'show_daddylive_channel_group':
        category = params.get('category')
        show_daddylive_channel_group(category)
    
    elif mode == 'play_daddylive_channel':
        channel_data = params.get('channel_data')
        play_daddylive_channel(channel_data)
    
    elif mode == 'show_a1xs_categories':
        show_a1xs_categories()
    
    elif mode == 'show_a1xs_channel_group':
        category = params.get('category')
        show_a1xs_channel_group(category)
    
    elif mode == 'play_a1xs_channel':
        channel_data = params.get('channel_data')
        play_a1xs_channel(channel_data)