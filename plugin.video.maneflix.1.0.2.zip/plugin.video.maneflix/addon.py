import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib.parse
import requests
import json
import time
import tempfile
import os

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')

TMDB_API_KEY = "a46c50a0ccb1bafe2b15665df7fad7e1"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"
STREAM_API_URL = "https://tmkt-api-production.up.railway.app/debug/stream"
SUBTITLE_API_URL = "https://sub.wyzie.ru/search"

POSTER_SIZE = "w500"
BACKDROP_SIZE = "w1280"

SESSION_API_URL = "https://tmkt-api-production.up.railway.app/debug/session"
SESSION_CACHE_FILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/session.json")
SESSION_EXPIRY = 60 * 60

def get_cached_session():
    if xbmcvfs.exists(SESSION_CACHE_FILE):
        try:
            with xbmcvfs.File(SESSION_CACHE_FILE, 'r') as f:
                data = json.load(f)
                token = data.get("token")
                ts = data.get("timestamp", 0)
                if token and (time.time() - ts) < SESSION_EXPIRY:
                    log(f"✅ Using cached session token: {token[:8]}...", xbmc.LOGINFO)
                    return token
        except Exception as e:
            log(f"❌ Failed reading session cache: {e}", xbmc.LOGERROR)

    token = fetch_new_session()
    if token:
        try:
            folder = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}")
            if not xbmcvfs.exists(folder):
                xbmcvfs.mkdirs(folder)
            with xbmcvfs.File(SESSION_CACHE_FILE, 'w') as f:
                json.dump({"token": token, "timestamp": time.time()}, f)
            log(f"✅ New session token cached: {token[:8]}...", xbmc.LOGINFO)
        except Exception as e:
            log(f"❌ Failed writing session cache: {e}", xbmc.LOGERROR)
    return token

def fetch_new_session():
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        response = requests.get(SESSION_API_URL, headers=headers, timeout=15)
        response.raise_for_status()
        data = response.json()
        token = data.get("session") or data.get("session_id")
        if token:
            return token
        log(f"❌ Session key missing in API response: {data}", xbmc.LOGERROR)
    except Exception as e:
        log(f"❌ Failed to fetch session: {e}", xbmc.LOGERROR)
    return None

def log(msg, level=xbmc.LOGINFO):
    """Log messages to Kodi log"""
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

def get_url(**kwargs):
    """Create a URL for the addon"""
    return f"plugin://{ADDON_ID}?{urllib.parse.urlencode(kwargs)}"

def make_request(url, params=None, timeout=10):
    """Make HTTP request with error handling"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json'
        }
        response = requests.get(url, params=params, headers=headers, timeout=timeout)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        log(f"Request failed: {url} - Error: {str(e)}", xbmc.LOGERROR)
        return None

class TMDBClient:
    """TMDB API client"""
    
    def __init__(self):
        self.api_key = TMDB_API_KEY
        self.base_params = {"api_key": self.api_key, "language": "en-US"}
    
    def get_movie_genres(self):
        """Get movie genres"""
        url = f"{TMDB_BASE_URL}/genre/movie/list"
        data = make_request(url, self.base_params)
        return data.get("genres", []) if data else []
    
    def get_tv_genres(self):
        """Get TV genres"""
        url = f"{TMDB_BASE_URL}/genre/tv/list"
        data = make_request(url, self.base_params)
        return data.get("genres", []) if data else []
    
    def get_popular_movies(self, page=1):
        """Get popular movies"""
        url = f"{TMDB_BASE_URL}/movie/popular"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_top_rated_movies(self, page=1):
        """Get top rated movies"""
        url = f"{TMDB_BASE_URL}/movie/top_rated"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_now_playing_movies(self, page=1):
        """Get now playing movies"""
        url = f"{TMDB_BASE_URL}/movie/now_playing"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_upcoming_movies(self, page=1):
        """Get upcoming movies"""
        url = f"{TMDB_BASE_URL}/movie/upcoming"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_popular_tv(self, page=1):
        """Get popular TV shows"""
        url = f"{TMDB_BASE_URL}/tv/popular"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_top_rated_tv(self, page=1):
        """Get top rated TV shows"""
        url = f"{TMDB_BASE_URL}/tv/top_rated"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_tv_on_air(self, page=1):
        """Get TV shows on the air"""
        url = f"{TMDB_BASE_URL}/tv/on_the_air"
        params = {**self.base_params, "page": page}
        return make_request(url, params)
    
    def get_movies_by_genre(self, genre_id, page=1):
        """Get movies by genre"""
        url = f"{TMDB_BASE_URL}/discover/movie"
        params = {
            **self.base_params,
            "with_genres": genre_id,
            "sort_by": "popularity.desc",
            "page": page
        }
        return make_request(url, params)
    
    def get_tv_by_genre(self, genre_id, page=1):
        """Get TV shows by genre"""
        url = f"{TMDB_BASE_URL}/discover/tv"
        params = {
            **self.base_params,
            "with_genres": genre_id,
            "sort_by": "popularity.desc",
            "page": page
        }
        return make_request(url, params)
    
    def search_movies(self, query, page=1):
        """Search movies"""
        url = f"{TMDB_BASE_URL}/search/movie"
        params = {**self.base_params, "query": query, "page": page}
        return make_request(url, params)
    
    def search_tv(self, query, page=1):
        """Search TV shows"""
        url = f"{TMDB_BASE_URL}/search/tv"
        params = {**self.base_params, "query": query, "page": page}
        return make_request(url, params)
    
    def get_movie_details(self, movie_id):
        """Get movie details"""
        url = f"{TMDB_BASE_URL}/movie/{movie_id}"
        params = {**self.base_params, "append_to_response": "credits,external_ids"}
        return make_request(url, params)
    
    def get_tv_details(self, tv_id):
        """Get TV show details"""
        url = f"{TMDB_BASE_URL}/tv/{tv_id}"
        params = {**self.base_params, "append_to_response": "credits,seasons,external_ids"}
        return make_request(url, params)
    
    def get_season_details(self, tv_id, season_number):
        """Get season details"""
        url = f"{TMDB_BASE_URL}/tv/{tv_id}/season/{season_number}"
        return make_request(url, self.base_params)
    
    def get_episode_details(self, tv_id, season_number, episode_number):
        """Get episode details"""
        url = f"{TMDB_BASE_URL}/tv/{tv_id}/season/{season_number}/episode/{episode_number}"
        params = {**self.base_params, "append_to_response": "external_ids"}
        return make_request(url, params)
    
    def get_trending_movies(self, page=1):
        """Get trending movies (week)"""
        url = f"{TMDB_BASE_URL}/trending/movie/week"
        params = {**self.base_params, "page": page}
        return make_request(url, params)

    def get_trending_tv(self, page=1):
        """Get trending TV shows (week)"""
        url = f"{TMDB_BASE_URL}/trending/tv/week"
        params = {**self.base_params, "page": page}
        return make_request(url, params)

    def get_tv_airing_today(self, page=1):
        """Get TV shows airing today"""
        url = f"{TMDB_BASE_URL}/tv/airing_today"
        params = {**self.base_params, "page": page}
        return make_request(url, params)

def get_stream_url(ttid, session_token=None):
    """Fetch stream URL safely with automatic session"""
    if not session_token:
        session_token = get_cached_session()
        if not session_token:
            xbmcgui.Dialog().notification(ADDON_NAME, "Session token unavailable", xbmcgui.NOTIFICATION_ERROR)
            return None

    try:
        headers = {"X-Session-Token": session_token}
        params = {"d": ttid}

        response = requests.get(STREAM_API_URL, headers=headers, params=params, timeout=30)
        log(response.status_code)
        if response.status_code == 429:
            detail = response.json().get("detail", "You have been rate limited")
            xbmcgui.Dialog().notification(ADDON_NAME, detail, "Please slow down")
            return None
        elif response.status_code == 200:
            data = response.json()
            return data.get("data", {}).get("stream_info", {}).get("url")
    except Exception as e:
        log(f"Stream API error: {str(e)}", xbmc.LOGERROR)
    
    return None

def get_tv_stream(tv_id, season, episode):
    """Get TV stream URL - uses the TV format directly"""
    try:
        tv_format = f"tv/{tv_id}/{season}/{episode}"
        
        return get_stream_url(tv_format)
    
    except Exception as e:
        log(f"TV Stream API error: {str(e)}", xbmc.LOGERROR)
    
    return None

def get_subtitles(tmdb_id, media_type="movie"):
    """Get subtitles from sub.wyzie.ru"""
    try:
        if media_type == "movie":
            url = f"{SUBTITLE_API_URL}?id={tmdb_id}&format=srt"
        else:  # tv
            url = f"{SUBTITLE_API_URL}?imdb={tmdb_id}&format=srt"
        
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        log(f"Subtitle error: {str(e)}", xbmc.LOGERROR)
    
    return []

def download_subtitle(subtitle_url):
    """Download subtitle file"""
    try:
        response = requests.get(subtitle_url, timeout=10)
        if response.status_code == 200:
            return response.text
    except Exception as e:
        log(f"Subtitle download error: {str(e)}", xbmc.LOGERROR)
    
    return ""

def show_subtitle_selector(subtitles_data):
    """Show subtitle selection dialog"""
    if not subtitles_data:
        return None
    
    items = []
    subtitle_items = []
    
    for sub in subtitles_data:
        language = sub.get("display", sub.get("language", "Unknown"))
        format_type = sub.get("format", "srt").upper()
        source = sub.get("source", "")
        
        label = f"{language} ({format_type})"
        if source:
            label += f" - {source}"
        
        items.append(label)
        subtitle_items.append(sub)

    items.append("No subtitles")
    
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Select Subtitles", items)
    
    if choice >= 0 and choice < len(subtitle_items):
        return subtitle_items[choice]
    
    return None

def play_stream(ttid, title):
    """Play stream WITHOUT subtitles"""
    stream_url = get_stream_url(ttid)
    
    if not stream_url:
        xbmcgui.Dialog().notification(ADDON_NAME, "Stream not available", xbmcgui.NOTIFICATION_ERROR)
        return
    
    if not stream_url.startswith("https://"):
        stream_url = f"https://{stream_url}"
    
    log(f"Playing (no subs): {stream_url[:100]}...")
    
    # Create list item
    list_item = xbmcgui.ListItem(path=stream_url, label=title)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)

    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    list_item.setProperty('inputstream.adaptive.stream_headers', 
                         'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

def play_tv_stream(tv_id, season, episode, title):
    """Play TV stream WITHOUT subtitles"""
    stream_url = get_tv_stream(tv_id, season, episode)
    
    if not stream_url:
        xbmcgui.Dialog().notification(ADDON_NAME, "TV stream not available", xbmcgui.NOTIFICATION_ERROR)
        return
    
    if not stream_url.startswith("https://"):
        stream_url = f"https://{stream_url}"
    
    log(f"Playing TV: {stream_url[:100]}...")
    
    list_item = xbmcgui.ListItem(path=stream_url, label=title)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    
    # Set up HLS playback
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    list_item.setProperty('inputstream.adaptive.stream_headers', 
                         'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

def play_stream_with_subs(ttid, title, tmdb_id=None, media_type="movie"):
    """Play stream WITH subtitle support"""
    stream_url = get_stream_url(ttid)
    
    if not stream_url:
        xbmcgui.Dialog().notification(ADDON_NAME, "Stream not available", xbmcgui.NOTIFICATION_ERROR)
        return
    
    subtitle_path = None
    
    if tmdb_id:
        # Get available subtitles
        subtitles = get_subtitles(tmdb_id, media_type)
        
        if subtitles:
            selected = show_subtitle_selector(subtitles)
            
            if selected and selected.get("url"):
                subtitle_url = selected["url"]
                
                sub_content = download_subtitle(subtitle_url)
                
                if sub_content:
                    temp_dir = xbmcvfs.translatePath("special://temp/")
                    sub_filename = f"sub_{tmdb_id}_{int(time.time())}.srt"
                    subtitle_path = os.path.join(temp_dir, sub_filename)
                    
                    try:
                        with open(subtitle_path, 'w', encoding='utf-8') as f:
                            f.write(sub_content)
                        log(f"Subtitles saved: {subtitle_path}")
                    except Exception as e:
                        log(f"Failed to save subtitles: {str(e)}", xbmc.LOGERROR)
                        subtitle_path = None
    
    if not stream_url.startswith("https://"):
        stream_url = f"https://{stream_url}"
    
    log(f"Playing: {stream_url[:100]}...")
    
    list_item = xbmcgui.ListItem(path=stream_url, label=title)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    list_item.setProperty('inputstream.adaptive.stream_headers', 
                         'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    
    if subtitle_path and os.path.exists(subtitle_path):
        list_item.setSubtitles([subtitle_path])
        log(f"Subtitles loaded from: {subtitle_path}")
    
    # Play the stream
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

def build_image_url(path, size="w500"):
    """Build TMDB image URL"""
    if not path:
        return ""
    return f"{IMAGE_BASE_URL}{size}{path}"

def main_menu():
    """Display main menu"""
    handle = int(sys.argv[1])
    
    items = [
        ("Movies", "movies", "DefaultFolder.png"),
        ("TV Shows", "tv_shows", "DefaultFolder.png"),
        ("Search", "search", "DefaultFolder.png")
    ]
    
    for label, action, icon in items:
        url = get_url(action=action)
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': icon, 'thumb': icon})
        list_item.setInfo('video', {'title': label})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)

def movies_menu():
    """Display movies menu with categories"""
    handle = int(sys.argv[1])
    
    categories = [
        ("Popular", "movie_popular"),
        ("Top Rated", "movie_top_rated"),
        ("Now Playing", "movie_now_playing"),
        ("Upcoming", "movie_upcoming"),
        ("Trending", "movie_trending"),  
        ("Genres", "movie_genres")
    ]
    
    for label, action in categories:
        url = get_url(action=action)
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        list_item.setInfo('video', {'title': label})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)

def tv_shows_menu():
    """Display TV shows menu with categories"""
    handle = int(sys.argv[1])
    
    categories = [
        ("Popular", "tv_popular"),
        ("Top Rated", "tv_top_rated"),
        ("On Air", "tv_on_air"),
        ("Airing Today", "tv_airing_today"),  
        ("Trending", "tv_trending"),          
        ("Genres", "tv_genres")
    ]
    
    for label, action in categories:
        url = get_url(action=action)
        list_item = xbmcgui.ListItem(label=label)
        list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        list_item.setInfo('video', {'title': label})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)

def list_movies(action, page=1):
    """List movies based on category"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    action_map = {
        "movie_popular": tmdb.get_popular_movies,
        "movie_top_rated": tmdb.get_top_rated_movies,
        "movie_now_playing": tmdb.get_now_playing_movies,
        "movie_upcoming": tmdb.get_upcoming_movies,
        "movie_trending": tmdb.get_trending_movies  
    }
    
    if action in action_map:
        data = action_map[action](page)
        if data and data.get("results"):
            for movie in data["results"]:
                title = movie.get("title", "Unknown")
                year = movie.get("release_date", "")[:4] if movie.get("release_date") else ""
                label = f"{title} ({year})" if year else title
                url = get_url(action="movie_details", id=movie["id"])
                
                list_item = xbmcgui.ListItem(label=label)
                poster = build_image_url(movie.get("poster_path"), POSTER_SIZE)
                fanart = build_image_url(movie.get("backdrop_path"), BACKDROP_SIZE)
                art = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart or ADDON_PATH + "/fanart.jpg"}
                list_item.setArt(art)
                
                info = {'title': title, 'year': int(year) if year.isdigit() else 0,
                        'plot': movie.get("overview", ""), 'rating': float(movie.get("vote_average", 0))}
                list_item.setInfo('video', info)
                
                xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
            
            # Pagination
            if data.get("total_pages", 0) > page:
                next_url = get_url(action=action, page=page + 1)
                next_item = xbmcgui.ListItem(label="Next Page")
                next_item.setArt({'icon': 'DefaultFolder.png'})
                xbmcplugin.addDirectoryItem(handle, next_url, next_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.endOfDirectory(handle)

def list_tv_shows(action, page=1):
    """List TV shows based on category"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    action_map = {
        "tv_popular": tmdb.get_popular_tv,
        "tv_top_rated": tmdb.get_top_rated_tv,
        "tv_on_air": tmdb.get_tv_on_air,
        "tv_airing_today": tmdb.get_tv_airing_today,  
        "tv_trending": tmdb.get_trending_tv         
    }
    
    if action in action_map:
        data = action_map[action](page)
        if data and data.get("results"):
            for tv in data["results"]:
                title = tv.get("name", "Unknown")
                year = tv.get("first_air_date", "")[:4] if tv.get("first_air_date") else ""
                label = f"{title} ({year})" if year else title
                url = get_url(action="tv_details", id=tv["id"])
                
                list_item = xbmcgui.ListItem(label=label)
                poster = build_image_url(tv.get("poster_path"), POSTER_SIZE)
                fanart = build_image_url(tv.get("backdrop_path"), BACKDROP_SIZE)
                art = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart or ADDON_PATH + "/fanart.jpg"}
                list_item.setArt(art)
                
                info = {'title': title, 'year': int(year) if year.isdigit() else 0,
                        'plot': tv.get("overview", ""), 'rating': float(tv.get("vote_average", 0))}
                list_item.setInfo('video', info)
                
                xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
            
            # Pagination
            if data.get("total_pages", 0) > page:
                next_url = get_url(action=action, page=page + 1)
                next_item = xbmcgui.ListItem(label="Next Page")
                next_item.setArt({'icon': 'DefaultFolder.png'})
                xbmcplugin.addDirectoryItem(handle, next_url, next_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'tvshows')
    xbmcplugin.endOfDirectory(handle)

def movie_genres():
    """Show movie genres"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    genres = tmdb.get_movie_genres()
    
    for genre in genres:
        url = get_url(action="movie_genre", id=genre["id"], name=genre["name"])
        list_item = xbmcgui.ListItem(label=genre["name"])
        list_item.setArt({'icon': 'DefaultFolder.png'})
        list_item.setInfo('video', {'title': genre["name"]})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)

def tv_genres():
    """Show TV genres"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    genres = tmdb.get_tv_genres()
    
    for genre in genres:
        url = get_url(action="tv_genre", id=genre["id"], name=genre["name"])
        list_item = xbmcgui.ListItem(label=genre["name"])
        list_item.setArt({'icon': 'DefaultFolder.png'})
        list_item.setInfo('video', {'title': genre["name"]})
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'files')
    xbmcplugin.endOfDirectory(handle)

def movies_by_genre(genre_id, page=1, genre_name=""):
    """Show movies by genre with pagination"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    data = tmdb.get_movies_by_genre(genre_id, page)
    
    xbmcplugin.setPluginCategory(handle, f"Movies - {genre_name}" if genre_name else "Movies")
    
    if data and data.get("results"):
        for movie in data["results"]:
            title = movie.get("title", "Unknown")
            year = movie.get("release_date", "")[:4] if movie.get("release_date") else ""
            label = f"{title} ({year})" if year else title
            
            url = get_url(action="movie_details", id=movie["id"])
            list_item = xbmcgui.ListItem(label=label)
            
            poster = build_image_url(movie.get("poster_path"), POSTER_SIZE)
            fanart = build_image_url(movie.get("backdrop_path"), BACKDROP_SIZE)
            
            art = {
                'icon': poster,
                'thumb': poster,
                'poster': poster,
                'fanart': fanart or ADDON_PATH + "/fanart.jpg"
            }
            list_item.setArt(art)
            
            info = {
                'title': title,
                'year': int(year) if year.isdigit() else 0,
                'plot': movie.get("overview", ""),
                'rating': float(movie.get("vote_average", 0))
            }
            list_item.setInfo('video', info)
            
            xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
        
        # Add pagination if available
        total_pages = data.get("total_pages", 0)
        total_results = data.get("total_results", 0)
        
        if total_pages > page:
            next_url = get_url(action="movie_genre", id=genre_id, page=page + 1, name=genre_name)
            next_item = xbmcgui.ListItem(label=f"Page {page + 1} of {total_pages}")
            next_item.setArt({'icon': 'DefaultFolder.png'})
            next_item.setInfo('video', {'title': f"Next Page ({page + 1}/{total_pages})"})
            xbmcplugin.addDirectoryItem(handle, next_url, next_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.endOfDirectory(handle)

def tv_by_genre(genre_id, page=1, genre_name=""):
    """Show TV shows by genre with pagination"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    data = tmdb.get_tv_by_genre(genre_id, page)
    
    xbmcplugin.setPluginCategory(handle, f"TV Shows - {genre_name}" if genre_name else "TV Shows")
    
    if data and data.get("results"):
        for tv in data["results"]:
            title = tv.get("name", "Unknown")
            year = tv.get("first_air_date", "")[:4] if tv.get("first_air_date") else ""
            label = f"{title} ({year})" if year else title
            
            url = get_url(action="tv_details", id=tv["id"])
            list_item = xbmcgui.ListItem(label=label)
            
            poster = build_image_url(tv.get("poster_path"), POSTER_SIZE)
            fanart = build_image_url(tv.get("backdrop_path"), BACKDROP_SIZE)
            
            art = {
                'icon': poster,
                'thumb': poster,
                'poster': poster,
                'fanart': fanart or ADDON_PATH + "/fanart.jpg"
            }
            list_item.setArt(art)
            
            info = {
                'title': title,
                'year': int(year) if year.isdigit() else 0,
                'plot': tv.get("overview", ""),
                'rating': float(tv.get("vote_average", 0))
            }
            list_item.setInfo('video', info)
            
            xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
        
        # Add pagination if available
        total_pages = data.get("total_pages", 0)
        
        if total_pages > page:
            next_url = get_url(action="tv_genre", id=genre_id, page=page + 1, name=genre_name)
            next_item = xbmcgui.ListItem(label=f"Page {page + 1} of {total_pages}")
            next_item.setArt({'icon': 'DefaultFolder.png'})
            next_item.setInfo('video', {'title': f"Next Page ({page + 1}/{total_pages})"})
            xbmcplugin.addDirectoryItem(handle, next_url, next_item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'tvshows')
    xbmcplugin.endOfDirectory(handle)

def movie_details(movie_id):
    """Show movie details and play option"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    movie = tmdb.get_movie_details(movie_id)
    
    if movie:
        title = movie.get("title", "Unknown")
        imdb_id = movie.get("imdb_id", "")
        
        if imdb_id:
            # Regular play WITHOUT subtitles
            play_url = get_url(action="play_movie", ttid=imdb_id, title=title)
            play_item = xbmcgui.ListItem(label=f"Play {title}")
            play_item.setArt({'icon': 'DefaultVideo.png'})
            play_item.setInfo('video', {'title': f"Play {title}"})
            play_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, play_url, play_item, isFolder=False)
            
            # Play WITH subtitles
            play_subs_url = get_url(action="play_movie_subs", ttid=imdb_id, tmdb_id=movie_id, title=title)
            play_subs_item = xbmcgui.ListItem(label=f"Play {title} with Subtitles")
            play_subs_item.setArt({'icon': 'DefaultVideo.png'})
            play_subs_item.setInfo('video', {'title': f"Play {title} with Subtitles"})
            play_subs_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, play_subs_url, play_subs_item, isFolder=False)
    
    xbmcplugin.setContent(handle, 'movies')
    xbmcplugin.endOfDirectory(handle)

def tv_details(tv_id):
    """Show TV show details and seasons"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    tv = tmdb.get_tv_details(tv_id)
    
    if tv and tv.get("seasons"):
        show_title = tv.get("name", "TV Show")
        
        for season in tv["seasons"]:
            if season.get("season_number", 0) > 0:  # Skip season 0
                season_num = season.get("season_number", 1)
                label = f"Season {season_num}"
                
                url = get_url(action="season_episodes", id=tv_id, season=season_num, show_title=show_title)
                item = xbmcgui.ListItem(label=label)
                
                poster = build_image_url(season.get("poster_path"), POSTER_SIZE)
                fanart = build_image_url(tv.get("backdrop_path"), BACKDROP_SIZE)
                
                art = {
                    'icon': poster or 'DefaultFolder.png',
                    'thumb': poster or 'DefaultFolder.png',
                    'fanart': fanart or ADDON_PATH + "/fanart.jpg"
                }
                item.setArt(art)
                
                info = {
                    'title': label,
                    'plot': season.get("overview", tv.get("overview", "")),
                    'tvshowtitle': show_title
                }
                item.setInfo('video', info)
                
                xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    
    xbmcplugin.setContent(handle, 'seasons')
    xbmcplugin.endOfDirectory(handle)

def season_episodes(tv_id, season_num, show_title=""):
    """List episodes in a season"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    season = tmdb.get_season_details(tv_id, season_num)
    
    if season and season.get("episodes"):
        for episode in season["episodes"]:
            ep_num = episode.get("episode_number", 1)
            title = episode.get("name", f"Episode {ep_num}")
            label = f"{ep_num}. {title}"
            
            # Use TV format: tv_id/season/episode
            play_url = get_url(
                action="play_tv", 
                tv_id=tv_id,
                season=season_num,
                episode=ep_num,
                title=f"{show_title} - S{season_num}E{ep_num}: {title}"
            )
            
            item = xbmcgui.ListItem(label=label)
            
            # Set artwork
            still = build_image_url(episode.get("still_path"), "w500")
            fanart = build_image_url(season.get("poster_path") or episode.get("still_path"), BACKDROP_SIZE)
            
            art = {
                'icon': still or 'DefaultVideo.png',
                'thumb': still or 'DefaultVideo.png',
                'fanart': fanart or ADDON_PATH + "/fanart.jpg"
            }
            item.setArt(art)
            
            # Set info
            info = {
                'title': title,
                'plot': episode.get("overview", ""),
                'episode': ep_num,
                'season': season_num,
                'tvshowtitle': show_title,
                'aired': episode.get("air_date", "")
            }
            item.setInfo('video', info)
            item.setProperty('IsPlayable', 'true')
            
            xbmcplugin.addDirectoryItem(handle, play_url, item, isFolder=False)
    
    xbmcplugin.setContent(handle, 'episodes')
    xbmcplugin.endOfDirectory(handle)

def search_menu():
    """Show search menu - only keyboard search"""
    keyboard_search()

def keyboard_search():
    """Get search query from keyboard"""
    keyboard = xbmc.Keyboard()
    keyboard.setHeading("Search for movies or TV shows")
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query:
            dialog = xbmcgui.Dialog()
            choice = dialog.select("Search in:", ["Movies", "TV Shows"])
            
            if choice == 0:
                perform_search(query, "movie")
            elif choice == 1:
                perform_search(query, "tv")

def perform_search(query, search_type, page=1):
    """Perform search and display results"""
    handle = int(sys.argv[1])
    tmdb = TMDBClient()
    
    if search_type == "movie":
        data = tmdb.search_movies(query, page)
        item_type = "movies"
    else:
        data = tmdb.search_tv(query, page)
        item_type = "tvshows"
    
    if data and data.get("results"):
        for item in data["results"]:
            if search_type == "movie":
                title = item.get("title", "Unknown")
                year = item.get("release_date", "")[:4] if item.get("release_date") else ""
                label = f"{title} ({year})" if year else title
                action = "movie_details"
                poster_path = item.get("poster_path")
            else:
                title = item.get("name", "Unknown")
                year = item.get("first_air_date", "")[:4] if item.get("first_air_date") else ""
                label = f"{title} ({year})" if year else title
                action = "tv_details"
                poster_path = item.get("poster_path")
            
            url = get_url(action=action, id=item["id"])
            list_item = xbmcgui.ListItem(label=label)
            
            poster = build_image_url(poster_path, POSTER_SIZE)
            fanart = build_image_url(item.get("backdrop_path"), BACKDROP_SIZE)
            
            art = {
                'icon': poster,
                'thumb': poster,
                'poster': poster,
                'fanart': fanart or ADDON_PATH + "/fanart.jpg"
            }
            list_item.setArt(art)
            
            info = {
                'title': title,
                'year': int(year) if year.isdigit() else 0,
                'plot': item.get("overview", ""),
                'rating': float(item.get("vote_average", 0))
            }
            list_item.setInfo('video', info)
            
            xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=True)
    
    xbmcplugin.setContent(handle, item_type)
    xbmcplugin.endOfDirectory(handle)

def router(paramstring):
    """Route requests"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    
    action = params.get("action", "main")
    page = int(params.get("page", 1))
    
    if action == "main":
        main_menu()
    elif action == "movies":
        movies_menu()
    elif action == "tv_shows":
        tv_shows_menu()
    elif action == "movie_popular":
        list_movies("movie_popular", page)
    elif action == "movie_top_rated":
        list_movies("movie_top_rated", page)
    elif action == "movie_now_playing":
        list_movies("movie_now_playing", page)
    elif action == "movie_upcoming":
        list_movies("movie_upcoming", page)
    elif action == "movie_genres":
        movie_genres()
    elif action == "movie_genre":
        movies_by_genre(params.get("id"), page, params.get("name", ""))
    elif action == "tv_popular":
        list_tv_shows("tv_popular", page)
    elif action == "tv_top_rated":
        list_tv_shows("tv_top_rated", page)
    elif action == "tv_on_air":
        list_tv_shows("tv_on_air", page)
    elif action == "tv_genres":
        tv_genres()
    elif action == "tv_genre":
        tv_by_genre(params.get("id"), page, params.get("name", ""))
    elif action == "movie_details":
        movie_details(params.get("id"))
    elif action == "tv_details":
        tv_details(params.get("id"))
    elif action == "movie_trending":
        list_movies("movie_trending", int(params.get("page", 1)))
    elif action == "tv_trending":
        list_tv_shows("tv_trending", int(params.get("page", 1)))
    elif action == "tv_airing_today":
        list_tv_shows("tv_airing_today", int(params.get("page", 1)))
    elif action == "season_episodes":
        season_episodes(
            params.get("id"), 
            int(params.get("season", 1)),
            params.get("show_title", "")
        )
    elif action == "search":
        search_menu()
    elif action == "keyboard_search":
        keyboard_search()
    elif action == "play_movie":
        play_stream(params.get("ttid"), params.get("title", "Movie"))
    elif action == "play_tv":
        play_tv_stream(
        params.get("tv_id"),
        int(params.get("season", 1)),
        int(params.get("episode", 1)),
        params.get("title", "TV Episode")
    )
    elif action == "play_movie_subs":
        play_stream_with_subs(
            params.get("ttid"),
            params.get("title", "Movie"),
            tmdb_id=params.get("tmdb_id"),
            media_type="movie"
        )
    else:
        main_menu()

if __name__ == "__main__":
    router(sys.argv[2][1:])